
// Link from mainx() into blinklib.cpp
// Called to start the sketch. 

void __attribute__((noreturn)) run(void);
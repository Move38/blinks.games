/*
 * BareMinimum.cpp
 *
 */ 

#include <Arduino.h>

#include "blink.h"

void setup() {
	// put your start up code here, it will run
	// every time this blink wakes up
	
}

void loop() {
	// put your main code here, to run repeatedly
	// every time a new frame of pixels is displayed
	// on the front of this blink

}

# Tools
## Programmers
- Pocket AVR Programmer - [$14.95 on Sparkfun](https://www.sparkfun.com/products/9825)
- ISP Pogo Adapter - [$9.95 on Sparkfun](https://www.sparkfun.com/products/11591)
-  ISP Pogo Adapter - [$6.50 on Tindie](https://www.tindie.com/products/madworm/tiny-avr-isp-pogo-pin-programming-adapter/)
